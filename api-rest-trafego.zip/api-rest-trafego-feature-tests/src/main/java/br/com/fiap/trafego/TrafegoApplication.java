package br.com.fiap.trafego;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrafegoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrafegoApplication.class, args);
	}

}
