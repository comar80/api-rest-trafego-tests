package br.com.fiap.trafego.dto;

public record TokenDTO(String token) {
}
