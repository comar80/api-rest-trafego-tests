# API REST para registro de tráfego
### Feita em Java usando Spring Boot, Spring Data JPA, Spring Security, Flyway, Lombock, JWT e Docker
Inserir credencias do banco de dados em application.properties

## Build e execução com Docker:
```sh
docker compose up --build
```

## MER
![MER do Banco de Dados](https://github.com/comar80/api-rest-trafego/blob/main/MER.jpg)